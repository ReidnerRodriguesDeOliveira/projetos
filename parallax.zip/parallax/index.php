﻿<?php

 $con = new PDO("mysql:host=localhost;dbname=blog","root","");
session_start();

$sql = $con->prepare("SELECT * FROM tema");
$sql->execute();
$rows = $sql->fetchAll(PDO::FETCH_CLASS);

$_SESSION['tema'] = $rows;

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Parallax Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <style>
  .cor{
    background-color: teal;
  }
  .fonte{
    font-family: 'Montserrat', sans-serif;
    font-weight: 700; line-height: 26.4px;

  }
  </style>
</head>
<body class="cor">
  <nav class="grey darken-3" role="navigation">
      <a id="logo-container" href="index.php" class="brand-logo right white-text"><img src="img/logo.png"></a>
      <ul class="left hide-on-med-and-down white-text">
        <li class="active"><a href="index.php" class="white-text">Inicio</a></li>
        <li><a href="Hollow_Knight.php" class="white-text">Hollow Knight</a></li>
        <li><a href="Dark_Souls" class="white-text">Dark Souls</a></li>
        <li><a href="eSports.php" class="white-text">eSports</a></li>
        <li><a href="Night_In_The_Woods.php" class="white-text">Night In The Woods</a></li>
        <li><a href="Metroidvania.php" class="white-text">Metroidvania</a></li>
        <li><a href="login.php" class="white-text">login</a></li>
        <li><a href="php/logout.php" class="white-text">logout</a></li>
      </ul>

      <ul id="nav-mobile" class="sidenav">
        <li class="active"><a href="index.php">inicio</a></li>
        <li><a href="Hollow_Knight.php">Hollow Knight</a></li>
        <li><a href="Dark_Souls.php">Dark Souls</a></li>
        <li><a href="eSports.php">eSports</a></li>
        <li><a href="Night_In_The_Woods.php">Night In The Woods</a></li>
        <li><a href="Metroidvania.php">Metroidvania</a></li>
        <li><a href="login.php">login</a></li>
        <li><a href="php/logout.php">logout</a></li>
      </ul>
      <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
  </nav>

  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <br><br>
        <h1 class="header center black-text text-lighten-2 fonte bold"><img src="img/logo2.png">Macaco games</h1>
        <div class="row center">
          <h5 class="header col s12 light">O melhor site de jogos, para a macacada.</h5>
          <h1><?php if (isset($_SESSION['usuario'])) {
                        echo "Bem vindo ".$_SESSION['usuario']->Nome;
                    }  ?></h1>
        </div>
        <br><br>

      </div>
    </div>
    <div class="parallax"><img src="img/wallpaper.jpg" alt="Unsplashed background img 1"></div>
  </div>

  

  <div class="container ">
    <div class="section">
      <!--   Icon Section   -->
      <div class="parallax-container valign-wrapper">
        <div class="section no-pad-bot">
          <div class="container">
            <div class="row center">
              <h5 class="header col s12 light"></h5>
            </div>
          </div>
        </div>
        <div class="parallax"><img src="img/hollow3.jpg" alt="Unsplashed background img 2"></div>
      </div>
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">Hollow knigt<i class="material-icons">games</i></h4>
              <p class="left-align light">Hollow knight foi produzido pela desenvolvedora independente Team
                Cherry,lançado em 24/fev/2017. Hollow Knight apresenta uma experiência
                magnífica, em um mundo encantador, explorando o melhor do tão famoso gênero
                metroidvania.<br><form method="get" action="Hollow_Knight.php" class="left">
                                  <button type="submit" class="btn waves-effect pulse">Ler mais</button>
                                  </form><br><br></p>
            </div>
          </div>

        </div>
      </div>

      <div class="container">
        <div class="section">
          <!--   Icon Section   -->
          <div class="parallax-container valign-wrapper">
            <div class="section no-pad-bot">
              <div class="container">
                <div class="row center">
                  <h5 class="header col s12 light"></h5>
                </div>
              </div>
            </div>
            <div class="parallax"><img src="img/dark.jpg" alt="Unsplashed background img 2"></div>
          </div>
              <div class="row">
                <div class="col s12 center z-depth-2 white hoverable">
                  <h3><i class="mdi-content-send brown-text"></i></h3>
                  <h4 class="center teal-text">Dark Souls<i class="material-icons">games</i></h4>
                  <p class="left-align light">Dark Souls é uma das series de jogos mais marcantes de toda historia
                    pois quem joga nunca esquece, tendo os bosses mais dificil que você possa ver. A historia é complexa e se passa
                    em um mundo medieval sombrio, com criaturas diferentes que podem ter origem nos mais profundos pesadelos do criador.
                    Cada jogo possui uma incrivel campanha que pode te entreter por mais de 50 Horas.<br><form method="get" action="Dark_Souls.php" class="left">
                                  <button type="submit" class="btn waves-effect pulse">Ler mais</button>
                                  </form><br><br></p>
                </div>
              </div>
    
            </div>
          </div>

          <div class="container">
            <div class="section">
              <!--   Icon Section   -->
              <div class="parallax-container valign-wrapper">
                <div class="section no-pad-bot">
                  <div class="container">
                    <div class="row center">
                      <h5 class="header col s12 light"></h5>
                    </div>
                  </div>
                </div>
                <div class="parallax"><img src="img/esports.png" alt="Unsplashed background img 2"></div>
              </div>
                  <div class="row">
                    <div class="col s12 center z-depth-2 white hoverable">
                      <h3><i class="mdi-content-send brown-text"></i></h3>
                      <h4 class="center teal-text">E-sports<i class="material-icons">games</i></h4>
                      <p class="left-align light">Os eSports podem ser um conceito relativamente novo, mas o jogo competitivo sempre esteve por ai.Na verdade, o primeiro torneio de video games ocorreu hรก mais de 45 anos na Universidade de Stanford.O Intergalactic Spacewar! Olympics de 1972 atraiu 20 pessoas para jogar em equipes de cinco e eventos livres para todos.Os jogos atingiram o grande público no final dos anos 70, mas, para a maioria das pessoas, tentar vencer a pontuação máxima foi o máximo de competitividade que isso envolveu. No entanto, apesar da logística, realizaram-se grandes torneios.<br><form method="get" action="eSports.php" class="left">
                                  <button type="submit" class="btn waves-effect pulse">Ler mais</button>
                                  </form><br><br></p>
                    </div>
                  </div>
        
                </div>
              </div>

              <div class="container">
                <div class="section">
                  <!--   Icon Section   -->
                  <div class="parallax-container valign-wrapper">
                    <div class="section no-pad-bot">
                      <div class="container">
                        <div class="row center">
                          <h5 class="header col s12 light"></h5>
                        </div>
                      </div>
                    </div>
                    <div class="parallax"><img src="img/night1.png" alt="Unsplashed background img 2"></div>
                  </div>
                      <div class="row">
                        <div class="col s12 center z-depth-2 white hoverable">
                          <h3><i class="mdi-content-send brown-text"></i></h3>
                          <h4 class="center teal-text">Night in the Woods<i class="material-icons">games</i></h4>
                          <p class="left-align light">Night in The Woods foi desenvolvido pela Infinte Fall e o estúdio australiano Secret Lab, publicado pela Finji. A história escrita por Bethany Hockenberry e Scott Benson conta a narrativa de nossa protagonista Mae Borowski, depois de voltar para sua cidade onde cresceu, a pequena e pacata Possum Springs.<br><form method="get" action="Night_In_The_Woods.php" class="left">
                                  <button type="submit" class="btn waves-effect pulse">Ler mais</button>
                                  </form><br><br></p>
                        </div>
                      </div>
            
                    </div>
                  </div>

                  <div class="container">
                    <div class="section">
                      <!--   Icon Section   -->
                      <div class="parallax-container valign-wrapper">
                        <div class="section no-pad-bot">
                          <div class="container">
                            <div class="row center">
                              <h5 class="header col s12 light"></h5>
                            </div>
                          </div>
                        </div>
                        <div class="parallax"><img src="img/cave.jpg" alt="Unsplashed background img 2"></div>
                      </div>
                          <div class="row">
                            <div class="col s12 center z-depth-2 white hoverable">
                              <h3><i class="mdi-content-send brown-text"></i></h3>
                              <h4 class="center teal-text">Metroidvania<i class="material-icons">games</i></h4>
                              <p class="left-align light">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam scelerisque id nunc nec volutpat. Etiam pellentesque tristique arcu, non consequat magna fermentum ac. Cras ut ultricies eros. Maecenas eros justo, ullamcorper a sapien id, viverra ultrices eros. Morbi sem neque, posuere et pretium eget, bibendum sollicitudin lacus. Aliquam eleifend sollicitudin diam, eu mattis nisl maximus sed. Nulla imperdiet semper molestie. Morbi massa odio, condimentum sed ipsum ac, gravida ultrices erat. Nullam eget dignissim mauris, non tristique erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae<br><form method="get" action="Metroidvania.php" class="left">
                                  <button type="submit" class="btn waves-effect pulse">Ler mais</button>
                                  </form><br><br></p>
                            </div>
                          </div>
                
                        </div>
                      </div>

<div class="row">
    <div class="col s12 m12">
      <div class="container">
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">Temas<i class="material-icons">filter_frames</i></h4>
              <div class="row">

        <div class="col-md-12">
        <form action="php/temas.php" method="post">
            <?php
             
        echo"<table class = 'striped'>";
            foreach ($_SESSION['tema'] as $row)
            {
    
            echo "<tr><td>$row->ID</td><td><a href='".$row->Nome.".php'>$row->Nome</a></td></tr>";
            }
        echo"</table>";
            ?>


        </form>
    </div>
            </div>
          </div>

        </div>
      </div>
          </div>
          </div>
      
  <footer class="page-footer teal">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">Bios</h5>
          <p class="grey-text text-lighten-4">Blog com os melhores textos de jogos</p>


        </div>
        <div class="col l3 s12">
          <h5 class="white-text">temas</h5>
          <ul>
            <li><a class="white-text" href="Hollow_Knight.php">Hollow Knight</a></li>
            <li><a class="white-text" href="Dark_Souls.php">Dark Souls</a></li>
            <li><a class="white-text" href="eSports.php">eSports</a></li>
            <li><a class="white-text" href="Night_In_The_Woods.php">Night In The Woods</a></li>
            <li><a class="white-text" href="Metroidvania.php">Metroidvania</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

  </body>
</html>
