<?php
$con = new PDO("mysql:host=localhost;dbname=blog","root","");
session_start();

if (isset($_POST["cadastrar"])) {


	$sql1 =$con->prepare("SELECT * FROM usuario where Email=?");
	$sql1->execute(array($_POST['email']));

	 $row = $sql1->fetchObject();

	 if ($row) {
       $_SESSION['Alerta_z'] = 1;
	
	     header("Location: ../cadastro.php");
       
    } else {

    $sql = $con->prepare("INSERT INTO usuario(Nome,Email,Senha,foto) VALUES(?,?,?,?)");
    $sql->execute(array($_POST['nome'], $_POST['email'], md5($_POST['senha']), $_POST['foto']));

    $_SESSION['Alerta_z'] = 0;
    $_SESSION['Alerta_y'] = 1;
    header("Location: ../login.php");
        
    }	

    
}else{$_SESSION['Alerta_y'] = 0;}
?>