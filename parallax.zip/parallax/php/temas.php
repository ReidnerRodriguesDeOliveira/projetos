<?php
$con = new PDO("mysql:host=localhost;dbname=blog","root","");
session_start();

$sql = $con->prepare("SELECT * FROM tema");
$sql->execute();
$rows = $sql->fetchAll(PDO::FETCH_CLASS);

$_SESSION['tema'] = $rows;

 header("Location: ../index.php");


?>