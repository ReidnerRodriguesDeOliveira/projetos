<?php
$con = new PDO("mysql:host=localhost;dbname=blog","root","");
session_start();

$temaid = $_SESSION['temaid'];


if (isset($_SESSION['usuario'])) {
    $userid = $_SESSION['usuario']->ID;
}
   
    
	$sql1 =$con->prepare("SELECT * FROM _like where Usuario_ID=? AND Tema_ID = ?");
	$sql1->execute(array($userid,$temaid));

	 $row = $sql1->fetchObject();

	 if ($row) {
       $sql2 = $con->prepare("DELETE from _like where Usuario_ID=? AND Tema_ID = ?");
    $sql2->execute(array($userid, $temaid));

     $sql =$con->prepare("SELECT COUNT(*) as contador FROM `_like` WHERE Tema_ID = ?");
    $sql->execute(array($temaid));  
    $linha = $sql->fetchObject();
    $_SESSION['joinhas'] = $linha;

     if ($temaid==1) {
    header("Location: ../eSports.php");
    }else if ($temaid==2) {
    header("Location: ../Dark_Souls.php");
    }else if ($temaid==3) {
    header("Location: ../Night_In_The_Woods.php");
    }else if ($temaid==4) {
    header("Location: ../Hollow_Knight.php");
    }else if ($temaid==5) {
      header("Location: ../Metroidvania.php");
      }
    else
    {
     $sql =$con->prepare("SELECT COUNT(*) as contador FROM `_like` WHERE Tema_ID = ?");
    $sql->execute(array($temaid));  
    $linha = $sql->fetchObject();
    $_SESSION['joinhas'] = $linha;

    header("Location: ../index.php");
    }
       
    } else {

    $sql3 = $con->prepare("INSERT INTO _like(Usuario_ID,Tema_ID) VALUES(?,?)");
    $sql3->execute(array($userid, $temaid));

 $sql =$con->prepare("SELECT COUNT(*) as contador FROM `_like` WHERE Tema_ID = ?");
    $sql->execute(array($temaid));  
    $linha = $sql->fetchObject();
    $_SESSION['joinhas'] = $linha;

    if ($temaid==1) {
      header("Location: ../eSports.php");
      }else if ($temaid==2) {
      header("Location: ../Dark_Souls.php");
      }else if ($temaid==3) {
      header("Location: ../Night_In_The_Woods.php");
      }else if ($temaid==4) {
      header("Location: ../Hollow_Knight.php");
      }else if ($temaid==5) {
        header("Location: ../Metroidvania.php");
      }else
    {   
    header("Location: ../index.php");
    }
       } 
    	

    

?>