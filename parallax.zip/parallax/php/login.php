<?php

session_start();
if (isset($_POST['entrar'])) {
    $con = new PDO("mysql:host=localhost; dbname=blog", "root", "");
    $sql = $con->prepare("SELECT * FROM usuario WHERE email=? AND senha=?");
    $sql->execute(array($_POST['email'], md5($_POST['senha'])));

    $row = $sql->fetchObject();  // devolve um único registro

// Se o usuário foi localizado
    if ($row) {
        $_SESSION['usuario'] = $row;
        $_SESSION['Alerta_x'] = 0;

        header("Location: ../index.php");
    } else {

        $_SESSION['Alerta_x'] = 1;
        header("Location: ../login.php");
    }
}
?>