<?php


$con = new PDO("mysql:host=localhost;dbname=blog","root","");
session_start();
$temaid = $_SESSION['temaid'];
if (isset($_SESSION['usuario'])) {
	$userid = $_SESSION['usuario']->ID;
}


if (isset($_POST["enviar"]))
{
    $sql = $con->prepare("INSERT INTO post(Data_,Mensagem,Usuario_ID,Tema_ID) VALUES(?,?,?,?)");
    $sql->execute(array(date("Y-m-d H:i"),$_POST['mensagem'],$userid,$temaid));

}

$sql1 = $con->prepare("SELECT p.Mensagem,p.Data_, u.Nome FROM post p join usuario u ON u.ID = p.Usuario_ID where Tema_ID = ?");
$sql1->execute(array($temaid));
$rows = $sql1->fetchAll(PDO::FETCH_CLASS);
$_SESSION['post'] = $rows;

if ($temaid==1) {
    header("Location: ../eSports.php");
    }else if ($temaid==2) {
    header("Location: ../Dark_Souls.php");
    }else if ($temaid==3) {
    header("Location: ../Night_In_The_Woods.php");
    }else if ($temaid==4) {
    header("Location: ../Hollow_Knight.php");
    }else if ($temaid==5) {
      header("Location: ../Metroidvania.php");
      }
else
{
	header("Location: ../index.php");
}






?>