﻿<?php 

session_start();

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Parallax Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <style>
  .cor{
    background-color: teal;
  }
  .fonte{
    font-family: 'Montserrat', sans-serif;
    font-weight: 700; line-height: 26.4px;

  }
  </style>
</head>
<body class="cor">
<nav class="grey darken-3" role="navigation">
      <a id="logo-container" href="index.php" class="brand-logo right white-text"><img src="img/logo.png"></a>
      <ul class="left hide-on-med-and-down white-text">
        <li><a href="index.php" class="white-text">Inicio</a></li>
        <li><a href="Hollow_Knight.php" class="white-text">Hollow Knight</a></li>
        <li><a href="Dark_Souls" class="white-text">Dark Souls</a></li>
        <li><a href="eSports.php" class="white-text">eSports</a></li>
        <li><a href="Night_In_The_Woods.php" class="white-text">Night In The Woods</a></li>
        <li><a href="Metroidvania.php" class="white-text">Metroidvania</a></li>
        <li class="active"><a href="login.php" class="white-text">login</a></li>
        <li><a href="php/logout.php" class="white-text">logout</a></li>
      </ul>

      <ul id="nav-mobile" class="sidenav">
        <li><a href="index.php">inicio</a></li>
        <li><a href="Hollow_Knight.php">Hollow Knight</a></li>
        <li><a href="Dark_Souls.php">Dark Souls</a></li>
        <li><a href="eSports.php">eSports</a></li>
        <li><a href="Night_In_The_Woods.php">Night In The Woods</a></li>
        <li><a href="Metroidvania.php">Metroidvania</a></li>
        <li class="active"><a href="login.php">login</a></li>
        <li><a href="php/logout.php">logout</a></li>
      </ul>
      <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
  </nav>

  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <br><br>
        <h1 class="header center black-text text-lighten-2 fonte bold"><img src="img/logo2.png">Macaco games</h1>
        <div class="row center">
          <h5 class="header col s12 light">O melhor site de jogos, para a macacada.</h5>
        </div>
        <br><br>

      </div>
    </div>
    <div class="parallax"><img src="img/wallpaper.jpg" alt="Unsplashed background img 1"></div>
  </div>

  

  <div class="container ">
    <div class="section">
      <!--   Icon Section   -->
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">login<i class="material-icons">account_circle</i></h4>
              <div class="row">
    <form class="col s12" action="php/login.php" method="post">
      <div class="row">

                 <div class="input-field col s6">
                    <label>Email</label>
                    <input type="email" name="email" id="email" class="validate">
                </div>
                <div class="input-field col s6">
                    <label>Senha</label>
                    <input type="password" name="senha" id="senha" class="validate">
                </div>

      <div class="row">
                    <div class="col s4">
                        <button type="submit" class="waves-effect waves-light btn-large" value = "entrar" name = "entrar" ><i class="material-icons right">send</i>entrar</button>
                    </div>
                    <div class="col s4">
                        <button type="reset" class="waves-effect waves-light btn-large"><i class="material-icons right">send</i>limpar</button>
                    </div>
                    <div class="col s4">
                        <a href="cadastro.php" class="waves-effect waves-light btn-large"><i class="material-icons right">send</i>cadastre-se</a>
                    </div>
                </div>

    </form>
  </div>
            </div>
          </div>

        </div>
      </div>
      
      <footer class="page-footer teal">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">Bios</h5>
          <p class="grey-text text-lighten-4">Blog com os melhores textos de jogos</p>


        </div>
        <div class="col l3 s12">
          <h5 class="white-text">temas</h5>
          <ul>
            <li><a class="white-text" href="Hollow_Knight.php">Hollow Knight</a></li>
            <li><a class="white-text" href="Dark_Souls.php">Dark Souls</a></li>
            <li><a class="white-text" href="eSports.php">eSports</a></li>
            <li><a class="white-text" href="Night_In_The_Woods.php">Night In The Woods</a></li>
            <li><a class="white-text" href="Metroidvania.php">Metroidvania</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

  </body>
  <?php

if (isset($_SESSION['Alerta_x'])){
if ($_SESSION['Alerta_x'] == 1){
    echo "<script>alert('Usuario ou senha invalido')</script>";
    unset($_SESSION['Alerta_x']);
}
}

if (isset($_SESSION['Alerta_y'])){
if ($_SESSION['Alerta_y'] == 1){
echo "<script>alert('Cadastrado com sucesso')</script>";
unset($_SESSION['Alerta_y']);
}
}

?>
</html>
