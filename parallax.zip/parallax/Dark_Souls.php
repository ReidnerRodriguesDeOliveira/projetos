﻿<?php

 $con = new PDO("mysql:host=localhost;dbname=blog","root","");
session_start();

$sql = $con->prepare("SELECT * FROM tema");
$sql->execute();
$rows = $sql->fetchAll(PDO::FETCH_CLASS);

$_SESSION['tema'] = $rows;

$_SESSION['temaid'] = 2;
$temaid = $_SESSION['temaid'];

if (isset($_SESSION['joinhas'])) {
  $joinha = $_SESSION['joinhas']->contador;
}

$sql1 = $con->prepare("SELECT p.Mensagem,p.Data_, u.Nome FROM post p join usuario u ON u.ID = p.Usuario_ID where Tema_ID = ?");
$sql1->execute(array($temaid));
$rows = $sql1->fetchAll(PDO::FETCH_CLASS);
$_SESSION['post'] = $rows;

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Parallax Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <style>
  .cor{
    background-color: teal;
  }
  .fonte{
    font-family: 'Montserrat', sans-serif;
    font-weight: 700; line-height: 26.4px;

  }
  </style>
</head>
<body class="cor">
<nav class="grey darken-3" role="navigation">
      <a id="logo-container" href="index.php" class="brand-logo right white-text"><img src="img/logo.png"></a>
      <ul class="left hide-on-med-and-down white-text">
        <li><a href="index.php" class="white-text">Inicio</a></li>
        <li><a href="Hollow_Knight.php" class="white-text">Hollow Knight</a></li>
        <li class="active"><a href="Dark_Souls" class="white-text">Dark Souls</a></li>
        <li><a href="eSports.php" class="white-text">eSports</a></li>
        <li><a href="Night_In_The_Woods.php" class="white-text">Night In The Woods</a></li>
        <li><a href="Metroidvania.php" class="white-text">Metroidvania</a></li>
        <li><a href="login.php" class="white-text">login</a></li>
        <li><a href="php/logout.php" class="white-text">logout</a></li>
      </ul>

      <ul id="nav-mobile" class="sidenav">
        <li><a href="index.php">inicio</a></li>
        <li><a href="Hollow_Knight.php">Hollow Knight</a></li>
        <li class="active"><a href="Dark_Souls.php">Dark Souls</a></li>
        <li><a href="eSports.php">eSports</a></li>
        <li><a href="Night_In_The_Woods.php">Night In The Woods</a></li>
        <li><a href="Metroidvania.php">Metroidvania</a></li>
        <li><a href="login.php">login</a></li>
        <li><a href="php/logout.php">logout</a></li>
      </ul>
      <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
  </nav>

  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <br><br>
        <h1 class="header center black-text text-lighten-2 fonte bold"><img src="img/logo2.png">Macaco games</h1>
        <div class="row center">
          <h5 class="header col s12 light">O melhor site de jogos, para a macacada.</h5>
          <h1><?php if (isset($_SESSION['usuario'])) {
                        echo "Bem vindo ".$_SESSION['usuario']->Nome;
                    }  ?></h1>
        </div>
        <br><br>

      </div>
    </div>
    <div class="parallax"><img src="img/wallpaper.jpg" alt="Unsplashed background img 1"></div>
  </div>

  

  <div class="container ">
    <div class="section">
      <!--   Icon Section   -->
      <div class="parallax-container valign-wrapper">
        <div class="section no-pad-bot">
          <div class="container">
            <div class="row center">
              <h5 class="header col s12 light"></h5>
            </div>
          </div>
        </div>
        <div class="parallax"><img src="img/Dark.jpg" alt="Unsplashed background img 2"></div>
      </div>
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">Dark Souls<i class="material-icons">games</i></h4>
              <p class="left-align light">Dark Souls é uma das series de jogos mais marcantes de toda historia pois quem joga nunca esquece, tendo os bosses mais dificil que você possa ver. A historia é complexa e se passa em um mundo medieval sombrio, com criaturas diferentes que podem ter origem nos mais profundos pesadelos do criador. Cada jogo possui uma incrivel campanha que pode te entreter por mais de 50 Horas.</p>
            
             <h4 class="center teal-text">Historia<i class="material-icons"></i></h4>
             <p class="left-align light">"Nos tempos antigos onde habitavam os anciões, o mundo ainda não possuía uma forma definida. Era uma terra fria e coberta de uma extensa e densa névoa, com imensos rochedos cinzentos que se estendiam sem fim e desfiladeiros repletos de gloriosas árvores antigas e colossais, com troncos que alcançavam os céus escuros e sombrios. E nesta terra, reinavam os grandiosos dragões imortais.
E logo surgiu o fogo no mundo, mas junto com o fogo surgiram também diferenças. Calor e frio, vida e morte... E o mais importante, a luz e a escuridão. E da escuridão eles vieram, e encontraram as almas de seus senhores que surgiam dentre as chamas emergentes. Nito, o primeiro dos mortos. A bruxa Izarith e suas filhas do chaos. Gwen, o senhor da luz solar e seus fieis cavaleiros e também a furtiva Pygmy, tão facilmente esquecida.
Com suas forças unidas, eles desafiaram os dragões. Gwen arremessava seus poderosos parafusos de eletricidade que sobrevoavam os céus e rasgavam a escamas de pedra de seus inimigos. As bruxas conjuravam grandes tempestades de fogo. Nito por onde passava, liberava ondas imensuráveis de doença e de morte.
Inesperadamente, Seath the Scaleless traiu sua própria espécie, e os dragões deixaram de existir. E logo veio a idade do fogo, mas logo as chamas irão se extinguir e apenas a escuridão irá prevalecer. Mesmo nos tempos atuais, existe apenas o calor do fogo queimando entre a madeira e o carvão, e o homem não enxerga mais a luz, e sim noites sem fim."
Este é o prólogo de Dark Souls, que possui um roteiro mínimo se comparado a maioria dos jogos modernos onde o foco se encontra em proporcionar uma experiência cada vez mais cinematográfica, onde o roteiro é entregue de forma natural conforme o avanço e seguindo um padrão de início, meio e fim. Em Dark Souls não funciona desta forma, temos aqui uma obra muito ambiciosa por parte da empresa nipônica From Software para os tempos atuais, onde o jogador simplesmente é arremessado ao mundo apenas com este prólogo acima em formato de um vídeo pré renderizado. Seus eventos e significados são entregues friamente à criatividade da pessoa atrás do controle, pois pouquíssimo conteúdo é mostrado ou explicado durante o jogo. Mas isso não quer dizer que Dark Souls não possua uma boa história.
Ela é apresentada através de personagens (NPC's) encontrados pelo mundo durante o decorrer da jogatina e através também da descrição de cada item encontrado, o que não são poucos. Há também pequenas cut-scenes, embora raras.
Cabe ao jogador interpretar o mundo e juntar as suas peças, essa é a intenção principal de seus idealizadores. Nada é entregue facilmente em Dark Souls, e isso não vale apenas para a história. Dark Souls realmente é um projeto ambicioso para os padrões atuais, e isso precisa ser recompensado não apenas por sua coragem em colocar no mercado um título que talvez não venda muito e que seja esquecido em poucos meses, e sim por sua qualidade e tentativa de não ser apenas mais um entre a maioria. Temos aqui um cenário de fantasia negra medieval muitíssimo bem elaborado e que realmente prende quem está olhando para a tela. A verdade é que Dark Souls esbanja tanta imersão e atmosfera, que nem sentimos falta de parar para ficar lendo e(ou) ouvindo centenas de linhas de texto/diálogo. Simplesmente não encaixaria isso no jogo, ele não foi projetado para ser assim. Apenas para exemplificar, sobre a falta de músicas também funciona o mesmo pensamento, a obra simplesmente não precisa de música durante a jogabilidade, não foi feito para ter.
A morte habita todos os cantos deste mundo decadente, seja com inimigos, abismos ou armadilhas mortais e para isso contamos com um sistema online muito original e refinado, onde os próprios jogadores podem livremente deixar avisos no chão para ajudar (ou não) os demais aventureiros. E tem mais, no exato ponto quando algum jogador morre, todos os demais que estão conectados naquele mesmo servidor poderão tocar em sua poça de sangue e acompanhar a trajetória que levou aquele jogador à morte, então quando avistar por exemplo diversas poças de sangue perto uma da outra, já comece a rezar e se prepare.
E não parando por aí, ainda é possível avistarmos outros jogadores vivos, ao redor, em tempo real por alguns momentos. Não é nada que atrapalha a experiência, pois o sistema online é feito para que isso aconteça somente de vez em quando, e de maneira breve. É como se estivermos jogando e virmos um vulto andando ao redor, em forma de "espírito", uma forma quase transparente. E, se não bastasse, ainda temos o modo Multiplayer sempre presentes durante a campanha principal, como o sistema Coop e competitivo.
            </p>

            <h4 class="center teal-text">Jogabilidade<i class="material-icons"></i></h4>
            <p class="left-align light">O que brilha realmente em Dark Souls, sem dúvida alguma é a sua jogabilidade. Controles extremamente rápidos e precisos deixam o jogador totalmente no controle de seu personagem. Neste jogo você irá morrer tanto, mas tanto, que se eu dissesse muito seria pouco, e em nenhuma das vezes será por culpa de alguma falha do jogo. 
Você certamente irá falar mal da mãe de todos os desenvolvedores, mas com o tempo irá começar a desconfiar que o real problema não seja com o jogo em si, e sim com você mesmo. Cada morte será um aprendizado, e cada movimento mal executado por menor que seja, poderia custar àquela vitória tão esperada após morrer incontáveis vezes. Será um motivo a mais para voltar tudo novamente desde o último checkpoint e vencer. É um jogo difícil sim, principalmente para os padrões atuais, mas que não é difícil por ter comandos ruins, movimentos atrasados, problemas técnicos, ou mesmo com um sistema de jogo quebrado ou mal projetado. A culpa será somente sua. Digamos que morrer faz parte da vida em Dark Souls. 
Com uma boa dose de persistência e paciência, qualquer jogador conseguirá se dar bem neste mundo que não perdoa nada os apressadinhos de primeira viagem. A exploração é extremamente importante, pois leva a muitas passagens secretas com itens que podem ser únicos e poderosíssimos. Portanto quem gosta de um bom desafio e exploração, esse é o jogo. Quando a coisa está feia de verdade, não entre em pânico ou pense em desistir, apenas pare um pouco a progressão e evolua mais os atributos do seu personagem e busque por itens, a técnica de "farmar" é válida aqui, embora não seja necessária em nenhum momento.
Dark Souls é um jogo de RPG de ação em terceira pessoa em cenário medieval de fantasia negra e podemos comparar a sua jogabilidade com jogos como "Severance: Blade of Darkness" ou "Enclave". Há a progressão de levels como na maioria dos jogos em formato RPG, mas os pontos não se originam de experiência ao derrotar inimigos, e sim de coletar suas almas. Cada inimigo morto acrescenta uma determinada quantia à sua coleção de almas e são através delas que a progressão ocorre. As almas além de serem usadas para subir de "soul level" (aumentando atributos principais), também são usadas para comprar itens em mercadores espalhados pelo mundo. As almas são a moeda principal em Dark Souls e caberá ao jogador saber quando e como usá-las, e também sempre há o risco de perdê-las. Isso mesmo, ao morrer, todo o seu estoque de almas é perdido momentaneamente, e caso queira vê-las novamente precisará voltar no mesmo ponto da sua última morte e clicar no objeto brilhante que estará lá presente. Se morrer novamente sem resgatar as suas almas, nunca mais irá voltar a vê-las.
            </p>

            <h4 class="center teal-text">Conclusão<i class="material-icons"></i></h4>
            <p class="left-align light">Obviamente que fica claro que Dark Souls  não fará sucesso e que é um jogo descartável para a maioria dos jogadores. Mas ele possui qualidades que apenas jogadores hardcores vão descobrir. Quem gosta de desafios de verdade e que não se importa com o visual genérico, vai se divertir bastante. Já quem está acostumado com outros RPG's famosos, pode esquecer Dar Souls. Ele não foi feito para você.</p>

            <form action="php/like.php" method="post">

                    <h5 class="left teal-text">Número de likes: <?php 
                      $con = new PDO("mysql:host=localhost;dbname=blog","root","");
                      $temaid = $_SESSION['temaid'];
                      $sql =$con->prepare("SELECT COUNT(*) as contador FROM `_like` WHERE Tema_ID = ?");
                      $sql->execute(array($temaid));  
                      $linha = $sql->fetchObject();
                      $_SESSION['joinhas'] = $linha;
                      $joinha =  $_SESSION['joinhas']->contador;
                    echo $joinha ?></h5>
            </form>

            <form action="php/post.php" method="post">

        <?php

            
       if (isset($_SESSION['usuario'])) {
          
          echo"<a href='php/like.php' class='btn waves-effect pulse left btn-large'><i class='material-icons'>thumb_up</i></a>
          <br><br><br><div class='col-md-12 center'>
            <div class='card col m8'>
            <h2 class='card-title'>Comentarios</h2>
            <form action='post_felipe.php' method='post'>
            <div class='col-md-12 justify-content-center'>
        <div class='form-group bg '>
                <div class='input-field col s10'>
                <textarea id='textarea' class='materialize-textarea' name='mensagem' placeholder='sua mensagem aqui'></textarea>
                <label for='Comentario'>Comentario</label>
              </div>
                <br>
                <div class='row'>
                    <div class='col-md-12'>
                        <button type='submit' class='btn btn-success btn-block button-group-justified' value = 'enviar' name = 'enviar'>enviar</button>
                    </div>
                    <br>
                </div>
        </div>
                </div>
            </form>
        </div>
    </div>";
        } 

        

?>
<table class='table table-striped'>
<?php

  foreach ($_SESSION['post'] as $row)
{
  
    $data = strtotime($row->Data_);
    $data1 = date("d/m H:i",$data);
    echo "<tr><td>$row->Nome</td> <td>$row->Mensagem</td> <td>$data1</td></tr>";

}
  ?>
</table>
</form>
            </div> 
          </div>
        </div>
      </div>



      
<div class="row">
    <div class="col s12 m12">
      <div class="container">
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">Temas<i class="material-icons">filter_frames</i></h4>
              <div class="row">

        <div class="col-md-12">
        <form action="php/temas.php" method="post">
            <?php
             
        echo"<table class = 'striped'>";
            foreach ($_SESSION['tema'] as $row)
            {
    
            echo "<tr><td>$row->ID</td><td><a href='".$row->Nome.".php'>$row->Nome</a></td></tr>";
            }
        echo"</table>";
            ?>


        </form>
    </div>
            </div>
          </div>

        </div>
      </div>
          </div>
          </div>
      
          <footer class="page-footer teal">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">Bios</h5>
          <p class="grey-text text-lighten-4">Blog com os melhores textos de jogos</p>


        </div>
        <div class="col l3 s12">
          <h5 class="white-text">temas</h5>
          <ul>
            <li><a class="white-text" href="Hollow_Knight.php">Hollow Knight</a></li>
            <li><a class="white-text" href="Dark_Souls.php">Dark Souls</a></li>
            <li><a class="white-text" href="eSports.php">eSports</a></li>
            <li><a class="white-text" href="Night_In_The_Woods.php">Night In The Woods</a></li>
            <li><a class="white-text" href="Metroidvania.php">Metroidvania</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

  </body>
</html>
