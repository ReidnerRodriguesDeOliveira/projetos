﻿<?php

 $con = new PDO("mysql:host=localhost;dbname=blog","root","");
session_start();

$sql = $con->prepare("SELECT * FROM tema");
$sql->execute();
$rows = $sql->fetchAll(PDO::FETCH_CLASS);

$_SESSION['tema'] = $rows;

$_SESSION['temaid'] = 4;
$temaid = $_SESSION['temaid'];

if (isset($_SESSION['joinhas'])) {
  $joinha = $_SESSION['joinhas']->contador;
}

$sql1 = $con->prepare("SELECT p.Mensagem,p.Data_, u.Nome FROM post p join usuario u ON u.ID = p.Usuario_ID where Tema_ID = ?");
$sql1->execute(array($temaid));
$rows = $sql1->fetchAll(PDO::FETCH_CLASS);
$_SESSION['post'] = $rows;

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Parallax Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <style>
  .cor{
    background-color: teal;
  }
  .fonte{
    font-family: 'Montserrat', sans-serif;
    font-weight: 700; line-height: 26.4px;

  }
  </style>
</head>
<body class="cor">
<nav class="grey darken-3" role="navigation">
      <a id="logo-container" href="index.php" class="brand-logo right white-text"><img src="img/logo.png"></a>
      <ul class="left hide-on-med-and-down white-text">
        <li><a href="index.php" class="white-text">Inicio</a></li>
        <li><a href="Hollow_Knight.php" class="white-text">Hollow Knight</a></li>
        <li><a href="Dark_Souls" class="white-text">Dark Souls</a></li>
        <li class="active"><a href="eSports.php" class="white-text">eSports</a></li>
        <li><a href="Night_In_The_Woods.php" class="white-text">Night In The Woods</a></li>
        <li><a href="Metroidvania.php" class="white-text">Metroidvania</a></li>
        <li><a href="login.php" class="white-text">login</a></li>
        <li><a href="php/logout.php" class="white-text">logout</a></li>
      </ul>

      <ul id="nav-mobile" class="sidenav">
        <li><a href="index.php">inicio</a></li>
        <li><a href="Hollow_Knight.php">Hollow Knight</a></li>
        <li><a href="Dark_Souls.php">Dark Souls</a></li>
        <li class="active"><a href="eSports.php">eSports</a></li>
        <li><a href="Night_In_The_Woods.php">Night In The Woods</a></li>
        <li><a href="Metroidvania.php">Metroidvania</a></li>
        <li><a href="login.php">login</a></li>
        <li><a href="php/logout.php">logout</a></li>
      </ul>
      <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
  </nav>

  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <br><br>
        <h1 class="header center black-text text-lighten-2 fonte bold"><img src="img/logo2.png">Macaco games</h1>
        <div class="row center">
          <h5 class="header col s12 light">O melhor site de jogos, para a macacada.</h5>
          <h1><?php if (isset($_SESSION['usuario'])) {
                        echo "Bem vindo ".$_SESSION['usuario']->Nome;
                    }  ?></h1>
        </div>
        <br><br>

      </div>
    </div>
    <div class="parallax"><img src="img/wallpaper.jpg" alt="Unsplashed background img 1"></div>
  </div>

  

  <div class="container ">
    <div class="section">
      <!--   Icon Section   -->
      <div class="parallax-container valign-wrapper">
        <div class="section no-pad-bot">
          <div class="container">
            <div class="row center">
              <h5 class="header col s12 light"></h5>
            </div>
          </div>
        </div>
        <div class="parallax"><img src="img/esports.png" alt="Unsplashed background img 2"></div>
      </div>
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">eSports<i class="material-icons">games</i></h4>
              <p class="left-align light">Os eSports podem ser um conceito relativamente novo, mas o jogo competitivo sempre esteve por ai.Na verdade, o primeiro torneio de video games ocorreu hรก mais de 45 anos na Universidade de Stanford.O Intergalactic Spacewar! Olympics de 1972 atraiu 20 pessoas para jogar em equipes de cinco e eventos livres para todos.Os jogos atingiram o grande público no final dos anos 70, mas, para a maioria das pessoas, tentar vencer a pontuação máxima foi o máximo de competitividade que isso envolveu. No entanto, apesar da logística, realizaram-se grandes torneios.</p>
            
             <h4 class="center teal-text">Historia<i class="material-icons"></i></h4>
             <p class="left-align light">Os eSports podem ser um conceito relativamente novo, mas o jogo competitivo sempre esteve por aí. Na verdade, o primeiro torneio de video games ocorreu há mais de 45 anos na Universidade de Stanford. O Intergalactic Spacewar! Olympics de 1972 atraiu 20 pessoas para jogar em equipes de cinco e eventos livres para todos. Os vencedores - Slim Tovar e Robert E. Maas (equipe) e Bruce Baumgart (solo) - receberam uma assinatura de um ano da revista Rolling Stone. (Você ainda pode jogar Spacewar! na máquina PDP-1 original no Museu da História do Computador em Mountain View, Califórnia, se estiver nas redondezas.)
Os jogos atingiram o grande público no final dos anos 70, mas, para a maioria das pessoas, tentar vencer a pontuação máxima foi o máximo de competitividade que isso envolveu. No entanto, apesar da logística, realizaram-se grandes torneios. O primeiro foi o Atari National Space Invaders Championship, que teve como vencedora Rebecca Heineman, em novembro de 1980.
Em 1981, Walter Day criou o Twin Galaxies, um banco de dados dos records de video games (ainda hoje uma fonte oficialmente reconhecida) e dois anos depois ele se tornou capitão do time do US National Video Game Team. Eles rodaram o país em um ônibus de 13 metros, lotado de fliperamas, desafiando a todos e instituindo disputas globais a serem jogadas nas embaixadas. A turnê culminou no torneio Video Game Masters de 1983, com os resultados indo parar no Livro dos Records Guinness de 1984.
Em 1988, um jogo pouco conhecido chamado Netrek abriria caminho para o futuro dos jogos online. Ele consistia em um jogo online de 16 jogadores que deveriam se enfrentar uns contra os outros no espaço, combinando elementos de estratégia em tempo real e tiros. À medida que a conectividade com a internet melhorou no início dos anos 90, mais e mais pessoas começaram a jogá-lo e, em 1993, a revista Wired o classificou como primeiro jogo de esportes online.

            </p>

            <h4 class="center teal-text">Dias Modernos<i class="material-icons"></i></h4>
            <p class="left-align light">O jogo competitivo ganhou ritmo na década de 90, iniciando com os Campeonatos Mundiais da Nintendo. A partir de 8 de março de 1990, o NWC visitou 30 estados nos EUA e no Canadá, com jogadores concorrentes em três faixas etárias. Eles jogaram com um cartucho personalizado no console NES (apenas 116 foram feitos e os colecionadores pagam muito por eles) que testou a coragem dos jogadores em Super Mario Bros, Rad Racer e Tetris.
Mas o torneio que foi dito ser o início dos eSports como os conhecemos hoje, foi o Red Annihilation de 1997 de Quake. Mais de 2 mil participantes jogaram uns contra os outros online em uma rede especial. Os 16 melhores foram levados para competir na E3 em uma arena no World Congress Center, onde Dennis 'Thresh' Fong venceu Tom 'Entropy' Kimzey e ganhou uma Ferrari 328 GTS que pertencera ao desenvolvedor de Quake, John Carmack.
Fong foi reconhecido como o primeiro jogador profissional do mundo e a ideia de ganhar a vida jogando começou a se disseminar entre gamers do mundo todo.
O World Cyber Games e a Electronic Sports League (agora ESL) foram lançados em 2000, com a Major League Gaming chegando em 2002. O divisor de águas veio nesse mesmo ano, com o lançamento do xBox Live trazendo o jogo online para consoles. O Halo 2 de 2004 foi o primeiro jogo a ser transmitido em TV aberta pela Major League Gaming.
Desde então, o crescimento dos eSports tem sido acelerado. Os patrocinadores levaram os torneios de pequenos salões para grandes centros de convenções e fizeram dos jogos uma lucrativa escolha de carreira. Os desenvolvedores perceberam o potencial e começaram a se envolver mais, o que levou a mais ganhos, melhores transmissões e valores de produção. A última peça do quebra-cabeça foi o surgimento da transmissão ao vivo através de plataformas como o Twitch, permitindo que jogadores em todo o mundo conseguissem uma renda estável sem ter que viajar e ganhar dinheiro em torneios.
Se tudo isso parece impressionante, se prepare. Apesar dos milhões de telespectadores e da receita esperada de bilhões de dólares para 2018, os eSports ainda estão crescendo e ainda não atingiram a população geral. Quando isso acontecer, os jogadores de hoje provavelmente serão verdadeiras estrelas esportivas do futuro.

            </p>

            <h4 class="center teal-text">Top 5 jogos de eSports (por valor do prêmio)<i class="material-icons"></i></h4>
            <p class="left-align light">Dota 2 - US$133,122,261
Uma sequência autônoma do mod Dota (Defence of the Ancients) para Warcraft 3, Dota 2 é um jogo MOBA (multiplayer online battle arena, ou arena de batalha multijogador online) de cinco por cinco, cujo objetivo é destruir o 'Ancião' da outra equipe. É completamente gratuito e atrai regularmente mais de um milhão de jogadores simultâneos no Steam.
League of Legends - US$49,501,718
Outro jogo gratuito que foi inspirado por Dota, o LoL World Championship do ano passado teve uma premiação de US$ 4.946.970, com a equipe Samsung Galaxy ganhando a maior parte da bolada.
Counter-Strike: Global Offensive - US$47,768,762
O quarto da série de tiro em primeira pessoa Counter-Strike, que coloca duas equipes, terroristas e antiterroristas, uns contra os outros.
StarCraft II - US$25,355,066
Sequência do jogo original de estratégia em tempo real de 1998, StarCraft II: Wings of Liberty recentemente se tornou grátis para jogar, embora você ainda tenha que comprar o pacote de expansão Legacy of the Void.
Heroes of the Storm - US$11,961,532
O MOBA da Blizzard possui personagens de seus maiores títulos, como WarCraft, StarCraft e Diablo, bem como do novo jogo Overwatch. Blizzard o considera um "hero brawler" online.
Um para ficar atento: Overwatch
Overwatch é um jogo multijogador de tiro em primeira pessoa que arrecadou críticas favoráveis e agora está sendo impulsionado a se tornar um grande título de eSports, com uma liga e conjunto de equipes permanentes. A primeira temporada acaba de começar e terminará com play-offs e um fim de semana de all-star em julho. As equipes competirão por uma premiação de 3,5 milhões de dólares.
</p>

            <form action="php/like.php" method="post">

                    <h5 class="left teal-text">Número de likes: <?php 
                      $con = new PDO("mysql:host=localhost;dbname=blog","root","");
                      $temaid = $_SESSION['temaid'];
                      $sql =$con->prepare("SELECT COUNT(*) as contador FROM `_like` WHERE Tema_ID = ?");
                      $sql->execute(array($temaid));  
                      $linha = $sql->fetchObject();
                      $_SESSION['joinhas'] = $linha;
                      $joinha =  $_SESSION['joinhas']->contador;
                    echo $joinha ?></h5>
            </form>

            <form action="php/post.php" method="post">

        <?php

            
       if (isset($_SESSION['usuario'])) {
          
          echo"<a href='php/like.php' class='btn waves-effect pulse left btn-large'><i class='material-icons'>thumb_up</i></a>
          <br><br><br><div class='col-md-12 center'>
            <div class='card col m8'>
            <h2 class='card-title'>Comentarios</h2>
            <form action='post_felipe.php' method='post'>
            <div class='col-md-12 justify-content-center'>
        <div class='form-group bg '>
                <div class='input-field col s10'>
                <textarea id='textarea' class='materialize-textarea' name='mensagem' placeholder='sua mensagem aqui'></textarea>
                <label for='Comentario'>Comentario</label>
              </div>
                <br>
                <div class='row'>
                    <div class='col-md-12'>
                        <button type='submit' class='btn btn-success btn-block button-group-justified' value = 'enviar' name = 'enviar'>enviar</button>
                    </div>
                    <br>
                </div>
        </div>
                </div>
            </form>
        </div>
    </div>";
        } 

        

?>
<table class='table table-striped'>
<?php

  foreach ($_SESSION['post'] as $row)
{
  
    $data = strtotime($row->Data_);
    $data1 = date("d/m H:i",$data);
    echo "<tr><td>$row->Nome</td> <td>$row->Mensagem</td> <td>$data1</td></tr>";

}
  ?>
</table>
</form>
            </div> 
          </div>
        </div>
      </div>



      
<div class="row">
    <div class="col s12 m12">
      <div class="container">
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">Temas<i class="material-icons">filter_frames</i></h4>
              <div class="row">

        <div class="col-md-12">
        <form action="php/temas.php" method="post">
            <?php
             
        echo"<table class = 'striped'>";
            foreach ($_SESSION['tema'] as $row)
            {
    
            echo "<tr><td>$row->ID</td><td><a href='".$row->Nome.".php'>$row->Nome</a></td></tr>";
            }
        echo"</table>";
            ?>


        </form>
    </div>
            </div>
          </div>

        </div>
      </div>
          </div>
          </div>
      
          <footer class="page-footer teal">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">Bios</h5>
          <p class="grey-text text-lighten-4">Blog com os melhores textos de jogos</p>


        </div>
        <div class="col l3 s12">
          <h5 class="white-text">temas</h5>
          <ul>
            <li><a class="white-text" href="Hollow_Knight.php">Hollow Knight</a></li>
            <li><a class="white-text" href="Dark_Souls.php">Dark Souls</a></li>
            <li><a class="white-text" href="eSports.php">eSports</a></li>
            <li><a class="white-text" href="Night_In_The_Woods.php">Night In The Woods</a></li>
            <li><a class="white-text" href="Metroidvania.php">Metroidvania</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

  </body>
</html>
